:-consult('display.pl').
:-consult('play.pl').
:-consult('utils.pl').
:-consult('input.pl').
:-consult('interface.pl').
:-consult('validations.pl').
:-consult('ai.pl').
:- use_module(library(lists)).
:- use_module(library(random)).
:- use_module(library(system)).
:- use_module(library(samsort)).

swack:-
    play.