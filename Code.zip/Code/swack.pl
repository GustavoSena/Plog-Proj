:-consult('display.pl').
:-consult('play.pl').
:-consult('utils.pl').
:-consult('input.pl').



:- use_module(library(lists)).

swack:-
    play.