# PLOG 2020/2021 - TP2

## Group: T07G0

| Name             | Number    | E-Mail              |
| ---------------- | --------- | ------------------- |
| Gustavo Sena     | 201806078 | up201806078@fe.up.pt|
| Maria Baia       | 201704951 | up201704951@fe.up.pt|

<br>

## Execução
<br>

Para executar o  jogo:

- Instale e execute o SICStus Prolog.
- Selecione File > Consult e selecione o file `dominosweeper.pl`.
- Digite `dominosweeper` na consola SICStus para iniciar o jogo.